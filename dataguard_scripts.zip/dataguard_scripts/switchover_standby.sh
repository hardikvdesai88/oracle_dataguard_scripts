

su - oracle -c "sqlplus / as sysdba @/home/oracle/switchover_to_standby.sql"
exit
ifup eth0:1
exit
