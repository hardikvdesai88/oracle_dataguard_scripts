
su - oracle -c "sqlplus / as sysdba @/home/oracle/switchover_to_primary.sql"
exit

ifup eth0:1
exit
