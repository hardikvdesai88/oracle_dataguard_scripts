
su - oracle -c "sqlplus / as sysdba @/home/oracle/failover_to_primary.sql"
exit

ifup eth0:1
exit
